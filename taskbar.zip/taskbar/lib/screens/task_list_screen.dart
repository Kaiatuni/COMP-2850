
import 'package:flutter/material.dart';
import '../models/task.dart';
import 'task_form_screen.dart';

class TaskListScreen extends StatefulWidget {
  @override
  _TaskListScreenState createState() => _TaskListScreenState();
}

class _TaskListScreenState extends State<TaskListScreen> {
  // Lista inicial de tareas de ejemplo
  List<Task> tasks = [
    Task(
        title: 'Completar actividad de Flutter',
        description: 'Terminar el código y el documento PDF.',
        dueDate: DateTime.now().add(Duration(days: 1)),
        isImportant: true),
  ];

  // Navega a la pantalla de formulario y añade la tarea recibida
  void _navigateToAddScreen() async {
    final newTask = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => TaskFormScreen()),
    );

    if (newTask != null && newTask is Task) {
      setState(() {
        tasks.add(newTask);
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Tarea "${newTask.title}" guardada')),
      );
    }
  }

  void _showDeleteConfirmation(BuildContext context, int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Eliminar Tarea'),
          content: Text('¿Está seguro de eliminar esta tarea?'),
          actions: [
            TextButton(
              child: Text('Cancelar'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            TextButton(
              child: Text('Eliminar'),
              onPressed: () {
                setState(() {
                  tasks.removeAt(index);
                });
                Navigator.of(context).pop(); // Cierra el diálogo

                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Tarea eliminada'))
                );
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Daily Planner'),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: tasks.isEmpty
          ? Center(child: Text('No hay tareas. ¡Añade una!'))
          : ListView.builder(
        itemCount: tasks.length,
        itemBuilder: (context, index) {
          final task = tasks[index];
          return Card(
            elevation: 1,
            margin: EdgeInsets.symmetric(vertical: 6, horizontal: 10),
            child: ListTile(
              title: Text(
                task.title,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  decoration: task.isDone
                      ? TextDecoration.lineThrough
                      : TextDecoration.none,
                  color: task.isImportant ? Colors.red.shade700 : Colors.black87,
                ),
              ),
              subtitle: Text(
                'Vence: ${task.dueDate.toLocal().toString().split(' ')[0]}',
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (task.isImportant)
                    Icon(Icons.star, color: Colors.amber, size: 20),

                  Checkbox(
                    value: task.isDone,
                    onChanged: (bool? value) {
                      setState(() {
                        task.isDone = value!;
                      });
                    },
                  ),

                  IconButton(
                    icon: Icon(Icons.delete, color: Colors.grey),
                    onPressed: () => _showDeleteConfirmation(context, index),
                  ),
                ],
              ),
              onTap: () {
                // Lógica de edición
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: _navigateToAddScreen,
      ),
    );
  }
}
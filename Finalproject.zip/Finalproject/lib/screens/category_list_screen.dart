import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/todo_provider.dart';
import '../widgets/category_card.dart';
import 'category_detail_screen.dart';

// Esta pantalla muestra la lista de todas las categorías de To-do.
// Es un StatelessWidget ya que las actualizaciones provienen del Provider.
class CategoryListScreen extends StatelessWidget {
  const CategoryListScreen({super.key});

  // --- Diálogo para Agregar o Editar una Categoría ---
  void _showCategoryDialog(BuildContext context, {String? categoryId, String? initialName})
  {
    // Usamos un TextEditingController para manejar la entrada de texto,
    // inicializado con el nombre actual si es una edición.
    final TextEditingController controller = TextEditingController(text: initialName ?? '');

    showDialog(
      context: context,
      builder: (_) {
        return AlertDialog(
          // El título cambia si es para crear una nueva o editar una existente.
          title: Text(categoryId == null ? 'Nueva Categoría' : 'Editar Categoría'),
          content: TextField(
            controller: controller,
            decoration: const InputDecoration(
              labelText: 'Nombre de la categoría',
            ),
          ),
          actions: [
            // Botón para cerrar el diálogo.
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancelar'),
            ),
            // Botón para guardar los cambios o crear la nueva categoría.
            ElevatedButton(
              onPressed: () {
                final name = controller.text.trim();
                if (name.isEmpty) return; // No hacemos nada si el campo está vacío.

                // Obtenemos el proveedor sin escuchar cambios (listen: false) para realizar la acción.
                final provider = Provider.of<TodoProvider>(context, listen: false);

                if (categoryId == null) {
                  // Si no hay ID, agregamos una nueva categoría.
                  provider.addCategory(name);
                } else {
                  // Si hay ID, actualizamos la categoría existente.
                  provider.updateCategory(categoryId, name);
                }
                Navigator.of(context).pop(); // Cerramos el diálogo.
              },
              child: const Text('Guardar'),
            ),
          ],
        );
      },
    );
  }

  // --- Diálogo de Confirmación para Eliminar Categoría ---
  void _confirmDeleteCategory(BuildContext context, String categoryId) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Eliminar categoría'),
        content: const Text('¿Estás seguro de eliminar esta categoría y todos sus Todos?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              // Obtenemos el proveedor para eliminar la categoría por su ID.
              Provider.of<TodoProvider>(context, listen: false).deleteCategory(categoryId);
              Navigator.pop(context); // Cerramos el diálogo de confirmación.
            },
            child: const Text('Eliminar'),
          ),
        ],
      ),
    );
  }

  // --- Construcción de la Interfaz de Usuario (UI) ---
  @override
  Widget build(BuildContext context) {
    // Escuchamos el TodoProvider para obtener la lista de categorías y
    // reconstruir la UI cuando la lista cambie.
    final provider = Provider.of<TodoProvider>(context);
    final categories = provider.categories;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mis Listas de Todos'),
      ),
      body: categories.isEmpty
          ? const Center(
        // Mensaje cuando no hay categorías creadas.
        child: Text('No hay categorías aún. Agrega una con el botón +'),
      )
          : ListView.builder(
        itemCount: categories.length,
        itemBuilder: (ctx, index) {
          final category = categories[index];

          // Usamos el widget CategoryCard para mostrar cada elemento.
          return CategoryCard(
            category: category,
            // Acción al tocar la tarjeta: Navega a la pantalla de detalles.
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  // Pasamos el ID de la categoría a la pantalla de detalle.
                  builder: (_) => CategoryDetailScreen(categoryId: category.id),
                ),
              );
            },
            // Acción al editar: Abre el diálogo con los datos precargados.
            onEdit: () {
              _showCategoryDialog(context, categoryId: category.id, initialName:
              category.name);
            },
            // Acción al eliminar: Abre el diálogo de confirmación.
            onDelete: () {
              _confirmDeleteCategory(context, category.id);
            },
          );
        },
      ),
      // Botón flotante para agregar una nueva categoría.
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showCategoryDialog(context),
        child: const Icon(Icons.add),
      ),
    );
  }
}
// En esta pantalla usamos el provider para obtener la lista de categorías y mostramos cada una con
// CategoryCard. El botón flotante (+) sirve para abrir un cuadro de diálogo donde se puede crear una
// nueva categoría. este tambien
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const VCardApp());
}

class VCardApp extends StatelessWidget {
  const VCardApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: VCardScreen(),
    );
  }
}

class VCardScreen extends StatelessWidget {
  const VCardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Se utiliza el color azul para el fondo
      backgroundColor: const Color(0xFFB2EBF2),
      appBar: AppBar(
        title: Text(
          'Mi V-Card Digital',
          style: GoogleFonts.openSans(
            fontWeight: FontWeight.bold,
            color: const Color(0xFF263238), // Gris Oscuro
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20.0),
          child: Container(
            padding: const EdgeInsets.all(20.0),
            // Contenedor principal con estilo de tarjeta
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15.0),
              boxShadow: [
                // Sombra sutil para efecto 3D
                BoxShadow(
                  color: Colors.grey.withOpacity(0.3),
                  spreadRadius: 2,
                  blurRadius: 7,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.min, // Ajusta la columna al contenido
              children: <Widget>[

                Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: const Color(0xFFB2EBF2), // Aqua Suave como borde
                      width: 4,
                    ),
                  ),
                  child: const CircleAvatar(
                    radius: 50,
                    backgroundImage: AssetImage('assets/profile.jpg'),
                  ),
                ),

                const SizedBox(height: 20),


                Text(
                  'Kivan M. Lopez Raices',
                  style: GoogleFonts.openSans(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF263238), // Gris Oscuro
                  ),
                ),

                const SizedBox(height: 5),


                Text(
                  'Desarrollador de ciencias de commputadora',
                  style: GoogleFonts.openSans(
                    fontSize: 18,
                    color: Colors.grey[600],
                  ),
                ),

                const SizedBox(height: 20),

                const Divider(
                    height: 1,
                    thickness: 1,
                    color: Color(0xFFE0E0E0) // Gris Cálido
                ),

                const SizedBox(height: 20),

                // --- Información de Contacto ---

                // Email
                Text(
                  'klopez2441@arecibointer.edu',
                  style: GoogleFonts.openSans(fontSize: 16),
                ),

                const SizedBox(height: 5),

                // Teléfono
                Text(
                  '+1 (123) 456-7890',
                  style: GoogleFonts.openSans(fontSize: 16),
                ),

                const SizedBox(height: 5),

                // Github con color de enlace
                Text(
                  'github.com/KaiAtUni',
                  style: GoogleFonts.openSans(
                    fontSize: 16,
                    color: Colors.blue,
                  ),
                ),

                const SizedBox(height: 20),

                // 4. Código QR
                Image.asset(
                  'assets/qrcode.png',
                  width: 100,
                  height: 100,
                ),

                const SizedBox(height: 20),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                      child: Text(
                        'Usuario de Github: KaiAtUni',
                        style: GoogleFonts.openSans(fontSize: 16),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
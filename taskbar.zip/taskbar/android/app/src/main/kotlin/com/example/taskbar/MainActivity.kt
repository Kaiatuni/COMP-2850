package com.example.taskbar

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/todo_provider.dart';
import '../models/todo_category.dart';
import '../models/todo_item.dart';
import '../widgets/todo_list_tile.dart';

// Definimos un enumerador para gestionar el estado de los filtros de To-do.
enum TodoFilter { all, pending, completed }

// Widget principal para la pantalla de detalles de la categoría.
class CategoryDetailScreen extends StatefulWidget {
  // El ID de la categoría que se va a mostrar, es requerido.
  final String categoryId;

  const CategoryDetailScreen({super.key, required this.categoryId});

  @override
  State<CategoryDetailScreen> createState() => _CategoryDetailScreenState();
}

class _CategoryDetailScreenState extends State<CategoryDetailScreen> {
  // Estado local para rastrear el filtro de To-do seleccionado actualmente.
  TodoFilter _currentFilter = TodoFilter.all;

  // --- Diálogo para Agregar/Editar To-do ---
  void _showTodoDialog(BuildContext context, TodoCategory category, {TodoItem? todo}) {
    // Determina si el diálogo es para editar (si se pasa un 'todo') o para crear uno nuevo.
    final isEdit = todo != null;
    // Controlador para el campo de texto de la descripción.
    final titleController = TextEditingController(text: todo?.title ?? '');
    // Almacena la fecha de vencimiento seleccionada.
    DateTime? selectedDate = todo?.dueDate;

    showDialog(
      context: context,
      // Usamos StatefulBuilder para actualizar el estado dentro del AlertDialog (solo la fecha).
      builder: (_) => StatefulBuilder(
        builder: (ctx, setLocalState) {
          // Función para mostrar el selector de fecha.
          Future<void> selectLocalDate() async {
            final now = DateTime.now();
            final picked = await showDatePicker(
              context: ctx,
              initialDate: selectedDate ?? now,
              firstDate: DateTime(now.year - 1),
              lastDate: DateTime(now.year + 5),
            );
            if (picked != null) {
              // Actualiza la UI local del diálogo con la nueva fecha.
              setLocalState(() {
                selectedDate = picked;
              });
            }
          }

          return AlertDialog(
            title: Text(isEdit ? 'Editar Todo' : 'Nuevo Todo'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Campo de texto para la descripción del To-do.
                  TextField(
                    controller: titleController,
                    decoration: const InputDecoration(
                      labelText: 'Descripción',
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Fila para mostrar y seleccionar la fecha de vencimiento.
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          selectedDate == null
                              ? 'Sin fecha objetivo'
                          // Formateamos la fecha a una representación simple.
                              : 'Fecha: ${selectedDate!.toLocal().toString().split(' ')[0]}',
                        ),
                      ),
                      TextButton(
                        onPressed: selectLocalDate,
                        child: const Text('Elegir fecha'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            // Botones de acción.
            actions: [
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(),
                child: const Text('Cancelar'),
              ),
              ElevatedButton(
                onPressed: () {
                  final text = titleController.text.trim();
                  if (text.isEmpty) return; // No guardar si el texto está vacío.

                  final provider = Provider.of<TodoProvider>(context, listen: false);

                  // Lógica para editar o agregar To-do.
                  if (isEdit) {
                    provider.updateTodo(
                      category.id,
                      todo!.id,
                      title: text,
                      dueDate: selectedDate,
                    );
                  } else {
                    provider.addTodo(category.id, text, selectedDate);
                  }

                  Navigator.of(ctx).pop(); // Cerramos el diálogo.
                },
                child: const Text('Guardar'),
              ),
            ],
          );
        },
      ),
    );
  }

  // --- Diálogo de Confirmación de Eliminación ---
  void _confirmDeleteTodo(BuildContext context, TodoCategory category, TodoItem todo) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Eliminar Todo'),
        content: const Text('¿Estás seguro de eliminar este Todo?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              // Llamamos al proveedor para eliminar la tarea.
              Provider.of<TodoProvider>(context, listen: false)
                  .deleteTodo(category.id, todo.id);
              Navigator.pop(context); // Cerramos el diálogo.
            },
            child: const Text('Eliminar'),
          ),
        ],
      ),
    );
  }

  // --- Lógica de Filtrado ---
  List<TodoItem> _applyFilter(TodoCategory category) {
    // Aplica el filtro seleccionado a la lista de To-dos de la categoría.
    switch (_currentFilter) {
      case TodoFilter.pending:
        return category.todos.where((t) => !t.isDone).toList();
      case TodoFilter.completed:
        return category.todos.where((t) => t.isDone).toList();
      case TodoFilter.all:
      default:
        return category.todos;
    }
  }

  // --- Construcción de la UI ---
  @override
  Widget build(BuildContext context) {
    // Escuchamos los cambios en el TodoProvider para reconstruir la UI cuando el estado cambia.
    final provider = Provider.of<TodoProvider>(context);
    // Obtenemos la categoría usando el ID pasado al widget.
    final category = provider.getCategoryById(widget.categoryId);

    // Manejo de caso si la categoría no se encuentra (e.g., fue eliminada en otra pantalla).
    if (category == null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Categoría no encontrada'),
        ),
        body: const Center(
          child: Text('La categoría ya no existe.'),
        ),
      );
    }

    // Obtenemos la lista de To-dos después de aplicar el filtro actual.
    final todos = _applyFilter(category);

    return Scaffold(
      appBar: AppBar(
        title: Text('Categoría: ${category.name}'),
      ),
      body: Column(
        children: [
          // --- Resumen de conteos ---
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                // Muestra el total de To-dos.
                Chip(
                  label: Text('Total: ${category.totalTodos}'),
                ),
                // Muestra el total de To-dos pendientes.
                Chip(
                  label: Text('Pendientes: ${category.pendingTodos}'),
                ),
                // Muestra el total de To-dos completados.
                Chip(
                  label: Text('Completados: ${category.completedTodos}'),
                ),
              ],
            ),
          ),

          // --- Filtros (ChoiceChips) ---
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Chip para mostrar 'Todos'.
                ChoiceChip(
                  label: const Text('Todos'),
                  selected: _currentFilter == TodoFilter.all,
                  onSelected: (_) {
                    setState(() {
                      _currentFilter = TodoFilter.all;
                    });
                  },
                ),
                const SizedBox(width: 8),
                // Chip para mostrar 'Pendientes'.
                ChoiceChip(
                  label: const Text('Pendientes'),
                  selected: _currentFilter == TodoFilter.pending,
                  onSelected: (_) {
                    setState(() {
                      _currentFilter = TodoFilter.pending;
                    });
                  },
                ),
                const SizedBox(width: 8),
                // Chip para mostrar 'Completados'.
                ChoiceChip(
                  label: const Text('Completados'),
                  selected: _currentFilter == TodoFilter.completed,
                  onSelected: (_) {
                    setState(() {
                      _currentFilter = TodoFilter.completed;
                    });
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),

          // --- Lista de Todos ---
          Expanded(
            child: todos.isEmpty
                ? const Center(
              // Mensaje cuando la lista está vacía en la vista actual.
              child: Text('No hay Todos en esta vista.'),
            )
                : ListView.builder(
              itemCount: todos.length,
              itemBuilder: (ctx, index) {
                final todo = todos[index];
                // Usamos un widget personalizado para cada elemento de la lista.
                return TodoListTile(
                  todo: todo,
                  // Callback para marcar/desmarcar como completado.
                  onChanged: (value) {
                    Provider.of<TodoProvider>(context, listen: false).updateTodo(
                      category.id,
                      todo.id,
                      isDone: value ?? false,
                    );
                  },
                  // Callback para editar (abre el diálogo de edición).
                  onEdit: () => _showTodoDialog(context, category, todo: todo),
                  // Callback para eliminar (abre el diálogo de confirmación).
                  onDelete: () => _confirmDeleteTodo(context, category, todo),
                );
              },
            ),
          ),
        ],
      ),
      // Botón flotante para agregar un nuevo To-do.
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showTodoDialog(context, category),
        child: const Icon(Icons.add),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/todo_provider.dart'; // Importamos nuestro gestor de estado.
import 'screens/category_list_screen.dart'; // Importamos la pantalla inicial.

// Función principal de Dart que inicia la aplicación Flutter.
void main() {
  runApp(const TodoApp());
}

// Widget principal que define la estructura y el tema de la aplicación.
// Es un StatelessWidget ya que su configuración es estática.
class TodoApp extends StatelessWidget {
  const TodoApp({super.key});

  @override
  Widget build(BuildContext context) {
    // 1. Configuración del Proveedor de Estado (Provider)
    // Usamos ChangeNotifierProvider para hacer que la instancia de TodoProvider
    // esté disponible para todos los widgets descendientes en el árbol.
    return ChangeNotifierProvider(
      // 'create' inicializa y proporciona la instancia de TodoProvider.
      create: (_) => TodoProvider(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false, // Oculta el banner de "Debug".
        title: 'Todo Categories App',

        // 2. Configuración del Tema
        theme: ThemeData(
          useMaterial3: true, // Habilita el diseño Material 3.
          // Define el esquema de colores basado en un color semilla azul.
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        ),

        // 3. Pantalla de Inicio
        // La pantalla inicial de la aplicación es CategoryListScreen.
        home: const CategoryListScreen(),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import '../models/todo_item.dart';

// Este widget representa una fila individual (Tile) para un To-do.
class TodoListTile extends StatelessWidget {
  // El objeto de la tarea (To-do) a mostrar.
  final TodoItem todo;
  // Callback ejecutado al cambiar el estado del Checkbox (marcar/desmarcar completado).
  final ValueChanged<bool?> onChanged;
  // Callback ejecutado al presionar la ficha (generalmente para editar).
  final VoidCallback onEdit;
  // Callback ejecutado al presionar el botón de eliminar.
  final VoidCallback onDelete;

  const TodoListTile({
    super.key,
    required this.todo,
    required this.onChanged,
    required this.onEdit,
    required this.onDelete,
  });

  // Función auxiliar para formatear la fecha de vencimiento.
  String _formatDate(DateTime? date) {
    if (date == null) return 'Sin fecha';
    // Tomamos la fecha local y solo conservamos la parte de la fecha (antes del primer espacio).
    return date.toLocal().toString().split(' ')[0];
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      // Leading: Checkbox para marcar la tarea como completada.
      leading: Checkbox(
        value: todo.isDone,
        onChanged: onChanged, // Llama al callback proporcionado.
      ),
      // Título: Descripción de la tarea.
      title: Text(
        todo.title,
        style: TextStyle(
          // Si la tarea está completada, aplica un tachado al texto.
          decoration: todo.isDone ? TextDecoration.lineThrough : TextDecoration.none,
        ),
      ),
      // Subtítulo: Muestra la fecha objetivo formateada.
      subtitle: Text('Fecha objetivo: ${_formatDate(todo.dueDate)}'),
      // Acción al tocar la ficha: Generalmente abre el diálogo de edición.
      onTap: onEdit,
      // Trailing: Botón para eliminar la tarea.
      trailing: IconButton(
        icon: const Icon(Icons.delete),
        onPressed: onDelete, // Llama al callback de eliminación.
      ),
    );
  }
}
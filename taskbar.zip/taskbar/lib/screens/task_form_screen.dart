// lib/screens/task_form_screen.dart

import 'package:flutter/material.dart';
import '../models/task.dart';

class TaskFormScreen extends StatefulWidget {
  @override
  _TaskFormScreenState createState() => _TaskFormScreenState();
}

class _TaskFormScreenState extends State<TaskFormScreen> {
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();

  DateTime? _selectedDate;
  bool _isImportant = false;

  // Función para mostrar el selector de fecha
  Future<void> _presentDatePicker() async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );

    if (pickedDate != null) {
      setState(() {
        _selectedDate = pickedDate;
      });
    }
  }

  // Función para guardar la tarea y volver, devolviendo el objeto Task
  void _saveTask() {
    if (_titleController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('El título no puede estar vacío.')),
      );
      return;
    }

    final newTask = Task(
      title: _titleController.text,
      description: _descriptionController.text.isNotEmpty
          ? _descriptionController.text
          : 'Sin descripción',
      dueDate: _selectedDate ?? DateTime.now(),
      isImportant: _isImportant,
    );

    // Devuelve la tarea a la pantalla anterior
    Navigator.pop(context, newTask);
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Agregar Tarea')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _titleController,
              decoration: InputDecoration(labelText: 'Título'),
            ),
            TextField(
              controller: _descriptionController,
              decoration: InputDecoration(labelText: 'Descripción'),
            ),
            Row(
              children: [
                Expanded(
                  child: Text(_selectedDate != null
                      ? 'Fecha: ${_selectedDate!.toLocal().toString().split(' ')[0]}'
                      : 'Seleccione una fecha'),
                ),
                IconButton(
                  icon: Icon(Icons.calendar_today),
                  onPressed: _presentDatePicker,
                ),
              ],
            ),
            SwitchListTile(
              title: Text('Importante'),
              value: _isImportant,
              onChanged: (bool value) {
                setState(() {
                  _isImportant = value;
                });
              },
            ),
            ElevatedButton(
              child: Text('Guardar Tarea'),
              onPressed: _saveTask,
            ),
          ],
        ),
      ),
    );
  }
}
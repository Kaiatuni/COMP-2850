package com.example.vcard

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

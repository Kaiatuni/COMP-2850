import 'package:flutter/foundation.dart';
import '../models/todo_category.dart';
import '../models/todo_item.dart';

// El TodoProvider gestiona el estado central de las categorías y las tareas (To-dos).
// Usa ChangeNotifier para notificar a los widgets (consumidores) sobre cualquier cambio en el estado.
class TodoProvider with ChangeNotifier {
  // Lista privada y mutable que almacena todas las categorías.
  final List<TodoCategory> _categories = [];

  // Getter público para acceder a las categorías.
  // Se utiliza List.unmodifiable para asegurar que la lista solo se modifique
  // a través de los métodos definidos en este Provider.
  List<TodoCategory> get categories => List.unmodifiable(_categories);

// Obtener una categoría por id
  TodoCategory? getCategoryById(String id) {
    try {
      // Busca la primera categoría cuyo ID coincida.
      return _categories.firstWhere((c) => c.id == id);
    } catch (_) {
      // Retorna null si no se encuentra ninguna categoría con ese ID.
      return null;
    }
  }

// ---------- CRUD de Categorías ----------

  // Agrega una nueva categoría a la lista.
  void addCategory(String name) {
    // Crea una nueva instancia de TodoCategory con un ID único basado en la marca de tiempo.
    final newCategory = TodoCategory(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
    );
    _categories.add(newCategory);
    // Notifica a todos los widgets que escuchan que el estado ha cambiado.
    notifyListeners();
  }

  // Actualiza el nombre de una categoría existente.
  void updateCategory(String id, String newName) {
    final category = getCategoryById(id);
    if (category != null) {
      category.name = newName;
      notifyListeners();
    }
  }

  // Elimina una categoría por su ID.
  void deleteCategory(String id) {
    // removeWhere elimina el elemento que cumple la condición.
    _categories.removeWhere((c) => c.id == id);
    notifyListeners();
  }

// ---------- CRUD de Todos ----------

  // Agrega un nuevo To-do a una categoría específica.
  void addTodo(String categoryId, String title, DateTime? dueDate) {
    final category = getCategoryById(categoryId);
    if (category != null) {
      // Crea la nueva tarea.
      final todo = TodoItem(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: title,
        dueDate: dueDate,
      );
      // Añade la tarea a la lista de To-dos de la categoría.
      category.todos.add(todo);
      notifyListeners();
    }
  }

  // Actualiza los campos de un To-do específico.
  void updateTodo(
      String categoryId,
      String todoId, {
        String? title,
        DateTime? dueDate,
        bool? isDone, // Se usa para marcar como completado/pendiente.
      }) {
    final category = getCategoryById(categoryId);
    if (category == null) return;

    // Encuentra el índice del To-do dentro de la lista de la categoría.
    final index = category.todos.indexWhere((t) => t.id == todoId);
    if (index == -1) return; // Si no se encuentra, salimos.

    final todo = category.todos[index];

    // Actualizamos los campos solo si se proporcionan valores nuevos (usando el operador ??).
    todo.title = title ?? todo.title;
    todo.dueDate = dueDate ?? todo.dueDate;

    // isDone es un booleano que se comprueba aparte.
    if (isDone != null) {
      todo.isDone = isDone;
    }

    // Ya que se modificó un objeto dentro de la lista de To-dos, notificamos los cambios.
    notifyListeners();
  }

  // Elimina un To-do específico de su categoría.
  void deleteTodo(String categoryId, String todoId) {
    final category = getCategoryById(categoryId);
    if (category == null) return;

    // Elimina el To-do que coincida con el ID dentro de la lista de la categoría.
    category.todos.removeWhere((t) => t.id == todoId);
    notifyListeners();
  }
}